






import {store} from './store2'
// import { autorun } from './autorun'
console.log(store.a)


// autorun(() => {
//     console.log(store.a, 'autoRun 打印')
// })




